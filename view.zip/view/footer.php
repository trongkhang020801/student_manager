	<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.2
        </div>
        <strong>Copyright &copy; 2021 <a href="">BKTKTCK</a>.</strong> All rights reserved.
     </footer>
      
  </body>
</html>